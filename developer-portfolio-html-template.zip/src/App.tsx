import About from "./components/About";
import CaseStudies from "./components/CaseStudies";
import Contact from "./components/Contact";
import Experience from "./components/Experience";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Nav from "./components/Nav";
import OpenSource from "./components/OpenSource";
import Skills from "./components/Skills";

export default function App() {
  return (
    <>
      <Nav />
      <Hero />
      <About />
      <Experience />
      <CaseStudies />
      <OpenSource />
      <Skills />
      <Contact />
      <Footer />
    </>
  );
}
