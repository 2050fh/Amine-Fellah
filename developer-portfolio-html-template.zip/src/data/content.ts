export const SOCIALS = {
  email: "fellah.amine2050@gmail.com",
  phone: "0562664409",
  instagram: "https://instagram.com/2050_fh",
  github: "https://github.com/aminefellah",
  linkedin: "https://linkedin.com/in/aminefellah",
};

export const caseStudies = [
  {
    num: "01",
    title: "AI Workflow Automation",
    outcome: "Saved the client ~15 hours of manual data entry every week",
    desc: "Designed and shipped a Python automation pipeline that ingests, cleans and routes business data automatically, replacing a manual spreadsheet workflow end-to-end.",
    stack: ["Python", "OpenAI API", "Pandas", "Cron"],
  },
  {
    num: "02",
    title: "Custom SaaS Dashboard",
    outcome: "Real-time analytics dashboard now used daily by the client's team",
    desc: "Built a responsive admin dashboard with live metrics, role-based access and a MongoDB-backed API to replace static reporting.",
    stack: ["React", "Node.js", "MongoDB", "Tailwind CSS"],
  },
  {
    num: "03",
    title: "AI Customer Support Bot",
    outcome: "Cut first-response time from hours to under a minute",
    desc: "Integrated a LangChain-powered chatbot into a business's WhatsApp line to answer FAQs and qualify leads automatically, 24/7.",
    stack: ["Python", "LangChain", "WhatsApp API"],
  },
  {
    num: "04",
    title: "E-commerce Storefront",
    outcome: "Improved page load speed and mobile conversion rate",
    desc: "Rebuilt a client's storefront from scratch with a fast, accessible UI, integrated payments and a headless content structure.",
    stack: ["React", "Vite", "Tailwind CSS", "Stripe"],
  },
  {
    num: "05",
    title: "Data Extraction Pipeline",
    outcome: "Automated collection of structured data from 10+ sources daily",
    desc: "Delivered a resilient scraping and normalization pipeline with scheduled runs, retry logic and clean exports for the client's internal tools.",
    stack: ["Python", "BeautifulSoup", "PostgreSQL"],
  },
  {
    num: "06",
    title: "Cross-Platform Mobile App",
    outcome: "Single codebase shipped to iOS and Android",
    desc: "Built and deployed a mobile app connected to a real-time backend, covering auth, push notifications and offline support.",
    stack: ["Flutter", "Firebase"],
  },
];

export const openSourceProjects = [
  {
    title: "AI Resume Analyzer",
    desc: "An open-source tool that parses resumes and uses an LLM to score them against a job description, with actionable feedback.",
    stack: ["Python", "Flask", "OpenAI API"],
    repo: "https://github.com/aminefellah/ai-resume-analyzer",
    demo: "#",
  },
  {
    title: "DevTrack",
    desc: "A lightweight task & project tracker for freelancers, with client boards, deadlines and a clean dark UI.",
    stack: ["React", "Node.js", "MongoDB"],
    repo: "https://github.com/aminefellah/devtrack",
    demo: "#",
  },
  {
    title: "WeatherSense",
    desc: "A minimalist weather app with location search, hourly forecasts and offline caching, built as a Flutter learning project turned product.",
    stack: ["Flutter", "REST API"],
    repo: "https://github.com/aminefellah/weathersense",
    demo: "#",
  },
];

export const techStack = [
  "JavaScript / TypeScript",
  "Python",
  "React",
  "Node.js",
  "Tailwind CSS",
  "Vite",
  "MongoDB",
  "PostgreSQL",
  "Flutter",
  "Firebase",
  "OpenAI API / LangChain",
  "Git & GitHub",
];

export const skillChips = {
  technical: ["AI Integration", "LLM Automation", "API Design", "Data Pipelines", "Mobile Apps"],
  interests: ["♟️ Chess", "📸 Photography", "🎨 Art", "🥊 Kickboxing", "🏃 Running", "🏋️ Lifting"],
};

export const experience = [
  {
    year: "Present",
    title: "Freelance AI & Web Developer",
    desc: "Designing and building AI-powered tools and full-stack web applications for private clients — from automation pipelines to custom dashboards and mobile apps.",
    tag: "Independent",
  },
  {
    year: "Present",
    title: "Student · Science & Technology",
    desc: "Chadli Bendjedid University of El Tarf — building a foundation in science and technology alongside hands-on, self-driven software development.",
    tag: "University",
  },
];
