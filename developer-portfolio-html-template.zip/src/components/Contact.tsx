import { FormEvent, useState } from "react";
import { SOCIALS } from "../data/content";
import { useReveal } from "../hooks/useReveal";
import { IconCheck, IconGithub, IconInstagram, IconLinkedin, IconMail, IconPhone } from "./icons";

const PROJECT_TYPES = ["AI Automation / Chatbot", "Web Application", "Mobile App", "Dashboard / SaaS Tool", "Other"];
const BUDGETS = ["< $500", "$500 – $1,500", "$1,500 – $5,000", "$5,000+", "Not sure yet"];
const TIMELINES = ["ASAP", "Within 2 weeks", "1 – 2 months", "Flexible"];

export default function Contact() {
  const ref = useReveal<HTMLElement>();
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    projectType: PROJECT_TYPES[0],
    budget: BUDGETS[0],
    timeline: TIMELINES[0],
    message: "",
  });

  const update = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`New project inquiry — ${form.projectType}`);
    const body = encodeURIComponent(
      `Name: ${form.name}\nEmail: ${form.email}\nProject type: ${form.projectType}\nBudget: ${form.budget}\nTimeline: ${form.timeline}\n\nMessage:\n${form.message}`
    );
    window.location.href = `mailto:${SOCIALS.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <section className="contact" id="contact" ref={ref}>
      <div className="wrap">
        <div className="contact-inner reveal">
          <span className="overline">Contact</span>
          <h2>
            Have a project? Let's <em>scope</em> it.
          </h2>
          <p className="contact-sub">
            Tell me a bit about what you need — project type, rough budget and timeline — and I'll get back to
            you within 24 hours to see if it's a good fit.
          </p>

          <div className="contact-grid">
            <div>
              {sent ? (
                <div className="success-box">
                  <IconCheck />
                  <span>
                    Thanks, {form.name || "there"}! Your email app should have opened with the details filled
                    in — just hit send. I'll reply within 24 hours.
                  </span>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="field-row">
                    <div className="field">
                      <label className="field-label">Name</label>
                      <input required type="text" placeholder="Your name" value={form.name} onChange={update("name")} />
                    </div>
                    <div className="field">
                      <label className="field-label">Email</label>
                      <input required type="email" placeholder="you@company.com" value={form.email} onChange={update("email")} />
                    </div>
                  </div>
                  <div className="field-row">
                    <div className="field">
                      <label className="field-label">Project type</label>
                      <select value={form.projectType} onChange={update("projectType")}>
                        {PROJECT_TYPES.map((p) => (
                          <option key={p}>{p}</option>
                        ))}
                      </select>
                    </div>
                    <div className="field">
                      <label className="field-label">Budget</label>
                      <select value={form.budget} onChange={update("budget")}>
                        {BUDGETS.map((b) => (
                          <option key={b}>{b}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="field">
                    <label className="field-label">Timeline</label>
                    <select value={form.timeline} onChange={update("timeline")}>
                      {TIMELINES.map((t) => (
                        <option key={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div className="field">
                    <label className="field-label">Project details</label>
                    <textarea
                      required
                      placeholder="What are you trying to build?"
                      value={form.message}
                      onChange={update("message")}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" style={{ width: "100%", justifyContent: "center" }}>
                    Send project brief
                  </button>
                  <p className="form-note">Opens your email client with everything pre-filled — no spam, ever.</p>
                </form>
              )}
            </div>

            <div>
              <p className="field-label" style={{ marginBottom: "16px" }}>
                Or reach out directly
              </p>
              <div className="contact-links">
                <a className="clink" href={`mailto:${SOCIALS.email}`}>
                  <IconMail />
                  {SOCIALS.email}
                </a>
                <a className="clink" href={`tel:${SOCIALS.phone}`}>
                  <IconPhone />
                  {SOCIALS.phone}
                </a>
                <a className="clink" href={SOCIALS.github} target="_blank" rel="noopener">
                  <IconGithub />
                  GitHub
                </a>
                <a className="clink" href={SOCIALS.linkedin} target="_blank" rel="noopener">
                  <IconLinkedin />
                  LinkedIn
                </a>
                <a className="clink" href={SOCIALS.instagram} target="_blank" rel="noopener">
                  <IconInstagram />
                  @2050_fh
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
