import { useEffect, useState } from "react";
import { SOCIALS } from "../data/content";
import { IconGithub, IconInstagram, IconLinkedin, IconMail } from "./icons";

function useLocalClock() {
  const [time, setTime] = useState("--:--:--");

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const t = new Date(utc + 3600000); // GMT+1
      const pad = (n: number) => (n < 10 ? "0" + n : "" + n);
      setTime(`${pad(t.getHours())}:${pad(t.getMinutes())}:${pad(t.getSeconds())}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return time;
}

export default function Footer() {
  const time = useLocalClock();
  const year = new Date().getFullYear();

  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <div className="foot-brand">
              Amine Fellah<span>.</span>
            </div>
            <p>
              AI &amp; Web Developer — freelance, based in El Tarf, Algeria. Building AI-powered tools and
              modern web &amp; mobile applications.
            </p>
            <div className="foot-socials">
              <a href={SOCIALS.github} target="_blank" rel="noopener" className="nav-icon" aria-label="GitHub">
                <IconGithub />
              </a>
              <a href={SOCIALS.linkedin} target="_blank" rel="noopener" className="nav-icon" aria-label="LinkedIn">
                <IconLinkedin />
              </a>
              <a href={SOCIALS.instagram} target="_blank" rel="noopener" className="nav-icon" aria-label="Instagram">
                <IconInstagram />
              </a>
              <a href={`mailto:${SOCIALS.email}`} className="nav-icon" aria-label="Email">
                <IconMail />
              </a>
            </div>
          </div>
          <div className="foot-col">
            <h5>Directory</h5>
            <a href="#about">About</a>
            <a href="#experience">Experience</a>
            <a href="#work">Case Studies</a>
            <a href="#projects">Projects</a>
            <a href="#skills">Skills</a>
            <a href="#contact">Contact</a>
          </div>
          <div className="foot-col">
            <h5>Connect</h5>
            <a href={SOCIALS.github} target="_blank" rel="noopener">
              GitHub
            </a>
            <a href={SOCIALS.linkedin} target="_blank" rel="noopener">
              LinkedIn
            </a>
            <a href={SOCIALS.instagram} target="_blank" rel="noopener">
              Instagram
            </a>
            <a href={`mailto:${SOCIALS.email}`}>Email</a>
          </div>
        </div>
        <div className="foot-bottom">
          <p>© {year} Amine Fellah. All rights reserved.</p>
          <p className="clock">Local Time / {time} (GMT+1)</p>
        </div>
      </div>
    </footer>
  );
}
