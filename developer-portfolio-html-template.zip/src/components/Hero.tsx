import { SOCIALS } from "../data/content";
import { IconGithub, IconInstagram, IconLinkedin } from "./icons";

export default function Hero() {
  return (
    <section className="hero" id="top">
      <div className="hero-bg"></div>
      <div className="wrap">
        <span className="overline">Freelance · Based in Algeria</span>
        <h1>
          Amine <em>Fellah</em>
          <br />
          builds with AI
          <br />
          &amp; the web.
        </h1>
        <p className="role">AI &amp; Web Developer</p>
        <p className="pitch">
          Freelance developer crafting intelligent, clean and reliable software — AI automations, full‑stack
          web apps and mobile products, built with a modern engineering stack.
        </p>
        <div className="hero-actions">
          <a href="#work" className="btn btn-primary">
            View case studies
          </a>
          <a href="#contact" className="btn btn-ghost">
            Let's talk
          </a>
        </div>
        <div className="hero-socials">
          <a href={SOCIALS.github} target="_blank" rel="noopener" className="nav-icon" aria-label="GitHub">
            <IconGithub />
          </a>
          <a href={SOCIALS.linkedin} target="_blank" rel="noopener" className="nav-icon" aria-label="LinkedIn">
            <IconLinkedin />
          </a>
          <a href={SOCIALS.instagram} target="_blank" rel="noopener" className="nav-icon" aria-label="Instagram">
            <IconInstagram />
          </a>
        </div>
      </div>
      <div className="scroll-cue">
        <span>Scroll</span>
        <span className="line"></span>
      </div>
    </section>
  );
}
