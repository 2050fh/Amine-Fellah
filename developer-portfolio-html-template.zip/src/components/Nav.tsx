import { useEffect, useState } from "react";
import { SOCIALS } from "../data/content";
import { IconGithub, IconLinkedin } from "./icons";

const LINKS = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#work", label: "Case Studies" },
  { href: "#projects", label: "Projects" },
  { href: "#skills", label: "Skills" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setOpen(false);

  return (
    <header className={`nav${scrolled ? " scrolled" : ""}`}>
      <div className="wrap nav-inner">
        <a href="#top" className="brand" onClick={closeMenu}>
          Amine<span>.</span>
        </a>
        <nav className={`nav-links${open ? " open" : ""}`}>
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={closeMenu}>
              {l.label}
            </a>
          ))}
          <a href={SOCIALS.github} target="_blank" rel="noopener" className="nav-icon" aria-label="GitHub">
            <IconGithub />
          </a>
          <a href={SOCIALS.linkedin} target="_blank" rel="noopener" className="nav-icon" aria-label="LinkedIn">
            <IconLinkedin />
          </a>
          <a href="#contact" className="nav-cta" onClick={closeMenu}>
            Get in touch
          </a>
        </nav>
        <button
          className={`burger${open ? " open" : ""}`}
          aria-label="Menu"
          onClick={() => setOpen((v) => !v)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </header>
  );
}
