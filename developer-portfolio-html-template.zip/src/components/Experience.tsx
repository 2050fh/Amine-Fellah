import { experience } from "../data/content";
import { useReveal } from "../hooks/useReveal";

export default function Experience() {
  const ref = useReveal<HTMLElement>();

  return (
    <section id="experience" ref={ref}>
      <div className="wrap">
        <div className="sec-head reveal">
          <span className="overline">Experience</span>
          <h2>
            Freelance work, <em>built to spec.</em>
          </h2>
        </div>
        <div className="exp-list">
          {experience.map((e) => (
            <div className="exp-row reveal" key={e.title}>
              <span className="yr">{e.year}</span>
              <div>
                <h3>{e.title}</h3>
                <p>{e.desc}</p>
              </div>
              <span className="tag">{e.tag}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
