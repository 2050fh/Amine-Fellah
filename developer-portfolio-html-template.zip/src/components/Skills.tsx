import { skillChips, techStack } from "../data/content";
import { useReveal } from "../hooks/useReveal";

export default function Skills() {
  const ref = useReveal<HTMLElement>();

  return (
    <section id="skills" ref={ref}>
      <div className="wrap">
        <div className="sec-head reveal">
          <span className="overline">Skills &amp; Interests</span>
          <h2>
            The stack I <em>build</em> with, and the life I <em>live</em> with.
          </h2>
        </div>
        <div className="skills-grid">
          <div className="skill-block reveal">
            <h4>Specialization</h4>
            <div className="chips">
              {skillChips.technical.map((c) => (
                <span className="chip" key={c}>
                  {c}
                </span>
              ))}
            </div>
          </div>
          <div className="skill-block reveal">
            <h4>Beyond Code</h4>
            <div className="chips">
              {skillChips.interests.map((c) => (
                <span className="chip" key={c}>
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="skill-block reveal" style={{ marginTop: "56px" }}>
          <h4>Tech Stack</h4>
          <div className="stack-grid">
            {techStack.map((t) => (
              <div className="stack-item" key={t}>
                <span className="dotmark"></span>
                <span>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
