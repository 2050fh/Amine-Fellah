import { caseStudies } from "../data/content";
import { useReveal } from "../hooks/useReveal";
import { IconLock, IconTrend } from "./icons";

export default function CaseStudies() {
  const ref = useReveal<HTMLElement>();

  return (
    <section id="work" ref={ref}>
      <div className="wrap">
        <div className="sec-head reveal">
          <span className="overline">Selected Work</span>
          <h2>
            Anonymous <em>case studies.</em>
          </h2>
          <p style={{ color: "var(--muted)", marginTop: "18px", fontSize: ".95rem" }}>
            Client names are protected by NDA — but the problems solved, the stack used and the results
            delivered are real.
          </p>
        </div>
        <div className="proj-grid">
          {caseStudies.map((p) => (
            <article className="proj-card reveal" key={p.num}>
              <div className="proj-top">
                <span className="proj-num">{p.num}</span>
                <span className="lock">
                  <IconLock />
                  NDA
                </span>
              </div>
              <h3>{p.title}</h3>
              <p className="outcome">
                <IconTrend />
                {p.outcome}
              </p>
              <p className="desc">{p.desc}</p>
              <div className="proj-stack">
                {p.stack.map((s) => (
                  <span className="stack-tag" key={s}>
                    {s}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
        <p className="proj-note reveal">Full case studies with metrics and screenshots are available on request, subject to client approval.</p>
      </div>
    </section>
  );
}
