import { openSourceProjects } from "../data/content";
import { useReveal } from "../hooks/useReveal";
import { IconArrowUpRight, IconCode, IconGithub } from "./icons";

export default function OpenSource() {
  const ref = useReveal<HTMLElement>();

  return (
    <section id="projects" ref={ref}>
      <div className="wrap">
        <div className="sec-head reveal">
          <span className="overline">Personal Projects</span>
          <h2>
            Built on my own time, <em>shipped in the open.</em>
          </h2>
        </div>
        <div className="oss-grid">
          {openSourceProjects.map((p) => (
            <article className="oss-card reveal" key={p.title}>
              <div className="oss-top">
                <div className="oss-icon">
                  <IconCode />
                </div>
                <div className="oss-links">
                  <a href={p.repo} target="_blank" rel="noopener" aria-label="View source on GitHub">
                    <IconGithub />
                  </a>
                  <a href={p.demo} target="_blank" rel="noopener" aria-label="View live demo">
                    <IconArrowUpRight />
                  </a>
                </div>
              </div>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
              <div className="oss-stack">
                {p.stack.map((s) => (
                  <span className="stack-tag" key={s}>
                    {s}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
