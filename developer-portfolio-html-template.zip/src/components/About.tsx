import { useReveal } from "../hooks/useReveal";

export default function About() {
  const ref = useReveal<HTMLElement>();

  return (
    <section id="about" ref={ref}>
      <div className="wrap">
        <div className="sec-head reveal">
          <span className="overline">About</span>
          <h2>
            A developer who thinks in <em>systems</em> — and moves like an athlete.
          </h2>
        </div>
        <div className="about-grid">
          <div className="about-body reveal">
            <p className="about-lead">
              I'm Amine, a freelance AI &amp; web developer building practical, production-grade software with
              AI, JavaScript and Python.
            </p>
            <p>
              I study Science &amp; Technology at Chadli Bendjedid University of El Tarf, and I spend my time
              turning ideas into working products for clients — from AI-driven automation to clean, responsive
              web and mobile experiences.
            </p>
            <p>
              Outside of code, I'm a chess player, photographer and artist, and I train in kickboxing, running
              and lifting. The same discipline I bring to sport is what I bring to every project: focus,
              patience and the drive to keep improving.
            </p>
          </div>
          <div className="about-facts reveal">
            <div className="fact">
              <span className="k">Based in</span>
              <span className="v">El Tarf, Algeria</span>
            </div>
            <div className="fact">
              <span className="k">University</span>
              <span className="v">Chadli Bendjedid Univ. (ST)</span>
            </div>
            <div className="fact">
              <span className="k">Focus</span>
              <span className="v">AI Systems · Full-Stack · Automation</span>
            </div>
            <div className="fact">
              <span className="k">Engagement</span>
              <span className="v">Remote · Worldwide clients</span>
            </div>
            <div className="fact">
              <span className="k">Status</span>
              <span className="v">Available for freelance</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
